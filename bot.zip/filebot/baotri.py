# Danh sách lệnh đang bảo trì
maintenance_commands = [
    "all",
]
